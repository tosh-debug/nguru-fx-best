import { useState, useEffect, useCallback, useRef } from "react";

// ══════════════════════════════════════════════════════════════════════════════
//  NgFX — Production Build v2.0
//  by Nguruh
//
//  LIVE DATA: Connects to Twelve Data API (free tier — forex + gold)
//  LICENSE:   30-day expiring keys validated on load
//  AUTO-RUN:  Scanner starts automatically, no button needed
//  ALERTS:    TP hit, SL hit, and signal fire notifications
// ══════════════════════════════════════════════════════════════════════════════

// ── DESIGN TOKENS ─────────────────────────────────────────────────────────────
const C={
  bg:"#04060e",chart:"#080d1a",
  glass:"rgba(255,255,255,0.03)",glassBorder:"rgba(255,255,255,0.07)",
  gold:"#f0b429",goldLight:"#ffd166",goldGlow:"rgba(240,180,41,0.14)",goldDim:"rgba(240,180,41,0.07)",
  blue:"#60a5fa",blueGlow:"rgba(96,165,250,0.11)",
  purple:"#c4b5fd",purpleGlow:"rgba(196,181,253,0.11)",
  green:"#34d399",greenGlow:"rgba(52,211,153,0.11)",greenDeep:"rgba(52,211,153,0.07)",
  red:"#f87171",redGlow:"rgba(248,113,113,0.11)",redDeep:"rgba(248,113,113,0.07)",
  amber:"#fbbf24",
  text:"#f0f4ff",textSub:"#94a3c4",textMuted:"#3d526e",
  border:"rgba(255,255,255,0.055)",
};
const FD="'Outfit',system-ui,sans-serif";
const FM="'JetBrains Mono',monospace";

// ══════════════════════════════════════════════════════════════════════════════
//  LICENSE KEY SYSTEM
//  Keys are SHA-256 hashed strings with an embedded expiry date.
//  Format: NGFX-YYYYMMDD-RANDOMHEX  (you generate these and sell them)
//  Validation checks format + expiry date client-side.
//
//  HOW TO GENERATE KEYS TO SELL:
//  1. Pick today's date + 30 days forward: e.g. 20261225
//  2. Generate random hex: Math.random().toString(16).slice(2,10).toUpperCase()
//  3. Combine: NGFX-20261225-A3F8B201
//  4. Sell that key — it expires on 25 Dec 2026
//
//  For server-side validation (recommended when scaling), replace
//  validateLicense() with a fetch() to your own endpoint.
// ══════════════════════════════════════════════════════════════════════════════
function validateLicense(key) {
  if (!key || typeof key !== "string") return { valid: false, reason: "No key entered" };
  const clean = key.trim().toUpperCase();
  // Format: NGFX-YYYYMMDD-XXXXXXXX
  const match = clean.match(/^NGFX-(\d{8})-([A-F0-9]{8})$/);
  if (!match) return { valid: false, reason: "Invalid key format. Expected: NGFX-YYYYMMDD-XXXXXXXX" };
  const expStr = match[1];
  const expDate = new Date(
    parseInt(expStr.slice(0,4)),
    parseInt(expStr.slice(4,6)) - 1,
    parseInt(expStr.slice(6,8))
  );
  if (isNaN(expDate.getTime())) return { valid: false, reason: "Invalid date in key" };
  const now = new Date();
  if (now > expDate) {
    const daysAgo = Math.floor((now - expDate) / 86400000);
    return { valid: false, reason: `Key expired ${daysAgo} day${daysAgo!==1?"s":""} ago. Contact Nguruh to renew.`, expired: true };
  }
  const daysLeft = Math.ceil((expDate - now) / 86400000);
  return { valid: true, daysLeft, expDate: expDate.toDateString() };
}

function getLicenseFromStorage() {
  try { return localStorage.getItem("ngfx_license") || ""; } catch { return ""; }
}
function saveLicense(key) {
  try { localStorage.setItem("ngfx_license", key); } catch {}
}

// ══════════════════════════════════════════════════════════════════════════════
//  LIVE DATA API — Twelve Data (free tier)
//  Sign up free at twelvedata.com — get an API key instantly
//  Free tier: 800 requests/day, 8 per minute — enough for this scanner
//
//  SYMBOL MAPPING:
//  XAU/USD → "XAU/USD"  (gold spot)
//  EUR/USD → "EUR/USD"
//  GBP/USD → "GBP/USD"
//
//  REPLACE "d7bed49a5f414c3ea1be206bd69096b1" below with your actual Twelve Data key.
//  The app will automatically switch to demo data if no key is set.
// ══════════════════════════════════════════════════════════════════════════════
const TWELVE_DATA_KEY = "d7bed49a5f414c3ea1be206bd69096b1"; // ← Twelve Data live key
const USE_LIVE_DATA   = TWELVE_DATA_KEY !== "YOUR_API_KEY";

async function fetchCandles(pair, interval="15min", outputSize=60) {
  if (!USE_LIVE_DATA) return null;
  try {
    const symbol = pair; // Twelve Data uses same format
    const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}&outputsize=${outputSize}&apikey=${TWELVE_DATA_KEY}`;
    const res  = await fetch(url);
    if (!res.ok) return null;
    const json = await res.json();
    if (json.status === "error" || !json.values) return null;
    // Convert to our OHLCV format (Twelve Data returns newest first — reverse)
    return json.values.slice().reverse().map(v => ({
      open:   parseFloat(v.open),
      high:   parseFloat(v.high),
      low:    parseFloat(v.low),
      close:  parseFloat(v.close),
      volume: parseFloat(v.volume || 1000),
      time:   new Date(v.datetime).getTime(),
    }));
  } catch { return null; }
}

async function fetchPrice(pair) {
  if (!USE_LIVE_DATA) return null;
  try {
    const url = `https://api.twelvedata.com/price?symbol=${encodeURIComponent(pair)}&apikey=${TWELVE_DATA_KEY}`;
    const res  = await fetch(url);
    const json = await res.json();
    return json.price ? parseFloat(json.price) : null;
  } catch { return null; }
}

// ── Demo data fallback ────────────────────────────────────────────────────────
function genCandles(base,n,vol,trend){
  let p=base;
  return Array.from({length:n},(_,i)=>{
    const ph=Math.sin(i/n*Math.PI);
    const push=(Math.random()-0.47+trend*0.1+ph*0.03)*vol;
    const o=p,c=p+push,wm=0.3+Math.random()*0.4;
    const h=Math.max(o,c)+Math.random()*vol*wm,l=Math.min(o,c)-Math.random()*vol*wm;
    const vb=600+Math.random()*1800,v=Math.random()<0.08?vb*2.5:vb;
    p=c;
    return{open:o,high:h,low:l,close:c,volume:v,time:Date.now()-((n-i)*5*60*1000)};
  });
}
function demoData(pair){
  const cfg={"XAU/USD":{base:2341.5,vol:2.8,trend:0.3},"EUR/USD":{base:1.0824,vol:0.0007,trend:-0.15},"GBP/USD":{base:1.2658,vol:0.0011,trend:0.12}};
  const c=cfg[pair],d=(Math.random()-0.5)*c.vol*1.5;
  return{m5:genCandles(c.base,60,c.vol*0.6,c.trend),m15:genCandles(c.base,60,c.vol,c.trend),h4:genCandles(c.base,60,c.vol*2.5,c.trend),price:c.base+d};
}

async function getPairData(pair) {
  if (!USE_LIVE_DATA) return demoData(pair);
  const [m5raw, m15raw, h4raw, livePrice] = await Promise.all([
    fetchCandles(pair,"5min",60),
    fetchCandles(pair,"15min",60),
    fetchCandles(pair,"4h",60),
    fetchPrice(pair),
  ]);
  if (!m15raw || !h4raw) return demoData(pair); // fallback
  const price = livePrice || (m15raw[m15raw.length-1]?.close);
  return{
    m5:  m5raw  || genCandles(price,60,0.001,0),
    m15: m15raw,
    h4:  h4raw,
    price,
  };
}

// ══════════════════════════════════════════════════════════════════════════════
//  TP / SL HIT MONITOR
//  After a signal fires, we track the live price against each TP and SL.
//  When price crosses a level, a push notification fires.
// ══════════════════════════════════════════════════════════════════════════════
function checkTPSL(signal, currentPrice) {
  if (!signal || !signal.calc || signal.result) return null;
  const isBuy = signal.direction === "BUY";
  const { tp1, tp2, tp3, sl } = signal.calc;
  const hit = [];
  if (isBuy) {
    if (currentPrice >= tp3 && !signal.tp3Hit) hit.push({ level:"TP3", price:tp3, type:"profit" });
    else if (currentPrice >= tp2 && !signal.tp2Hit) hit.push({ level:"TP2", price:tp2, type:"profit" });
    else if (currentPrice >= tp1 && !signal.tp1Hit) hit.push({ level:"TP1", price:tp1, type:"profit" });
    if (currentPrice <= sl  && !signal.slHit)  hit.push({ level:"SL",  price:sl,  type:"loss"   });
  } else {
    if (currentPrice <= tp3 && !signal.tp3Hit) hit.push({ level:"TP3", price:tp3, type:"profit" });
    else if (currentPrice <= tp2 && !signal.tp2Hit) hit.push({ level:"TP2", price:tp2, type:"profit" });
    else if (currentPrice <= tp1 && !signal.tp1Hit) hit.push({ level:"TP1", price:tp1, type:"profit" });
    if (currentPrice >= sl  && !signal.slHit)  hit.push({ level:"SL",  price:sl,  type:"loss"   });
  }
  return hit.length ? hit[0] : null;
}

function pushTPSLNotif(signal, hit) {
  if (Notification.permission !== "granted") return;
  const emoji = hit.type === "profit" ? "🟢" : "🔴";
  const icon  = hit.level === "SL" ? "⛔" : hit.level === "TP1" ? "🎯" : hit.level === "TP2" ? "🎯🎯" : "🏆";
  new Notification(`${icon} ${signal.pair} — ${hit.level} Hit!`, {
    body: `${emoji} Your ${signal.direction} trade hit ${hit.level} at ${hit.price}\n${hit.type === "profit" ? "Take your profit!" : "Stop loss reached — protect your capital."}`,
    tag:  `${signal.id}-${hit.level}`,
  });
}

// ══════════════════════════════════════════════════════════════════════════════
//  DAY TRADER CONFIG
// ══════════════════════════════════════════════════════════════════════════════
const DT = { maxHoldMins:240, minRR:2.5, scoreThreshold:55, noTradeHour:19 };

// ══════════════════════════════════════════════════════════════════════════════
//  WIN PROBABILITY WEIGHTS
// ══════════════════════════════════════════════════════════════════════════════
const CW={
  h4BiasAligned:     {label:"H4 bias",      weight:18},
  breakOfStructure:  {label:"BOS",          weight:14},
  keyLevelConfluence:{label:"Key level",    weight:20},
  orderBlock:        {label:"Order block",  weight:16},
  fairValueGap:      {label:"FVG",          weight:12},
  volumeSpike:       {label:"Vol spike",    weight:18},
  cvdDivergence:     {label:"CVD div",      weight:15},
  rejectionCandle:   {label:"Rejection",    weight:16},
  liquiditySweep:    {label:"Liq sweep",    weight:20},
  londonSession:     {label:"London",       weight:12},
  nyOverlap:         {label:"NY overlap",   weight:14},
  cleanSL:           {label:"Clean SL",     weight:10},
  multiConfluence:   {label:"3+ confluences",weight:8},
  intradayMomentum:  {label:"Intraday mom", weight:14},
  m5Confirmation:    {label:"M5 confirm",   weight:12},
  rsiConfluence:     {label:"RSI extreme",  weight:10},
};
function calcProb(keys){if(!keys.length)return 28;const w=keys.reduce((s,k)=>s+(CW[k]?.weight||0),0);return Math.min(88,Math.round(28+w/1.6));}
function probColor(p){return p>=75?C.green:p>=60?C.amber:C.red;}
function probLabel(p){return p>=75?"High probability":p>=60?"Moderate":"Lower probability";}
function probMult(p) {return p>=75?1.0:p>=60?0.75:0.5;}

// ══════════════════════════════════════════════════════════════════════════════
//  NEWS FILTER
// ══════════════════════════════════════════════════════════════════════════════
const NEWS=[{h:13,m:30,label:"NFP",days:[5]},{h:13,m:30,label:"US CPI",days:[2]},{h:19,m:0,label:"FOMC",days:[3]},{h:13,m:30,label:"GDP",days:[4]},{h:9,m:0,label:"BOE",days:[4]},{h:8,m:30,label:"UK CPI",days:[3]},{h:13,m:30,label:"Retail",days:[2]},{h:10,m:0,label:"ISM PMI",days:[1]}];
function getNews(){const now=new Date(),h=now.getUTCHours(),m=now.getUTCMinutes(),dow=now.getUTCDay(),nm=h*60+m;for(const ev of NEWS){if(ev.days&&!ev.days.includes(dow))continue;const em=ev.h*60+ev.m,diff=nm-em;if(diff>=-30&&diff<=30)return{blocked:true,label:ev.label};}return{blocked:false};}

// ══════════════════════════════════════════════════════════════════════════════
//  SESSIONS
// ══════════════════════════════════════════════════════════════════════════════
const SESS={london:{label:"London Open",emoji:"🇬🇧",pairs:["EUR/USD","GBP/USD","XAU/USD"]},overlap:{label:"London·NY",emoji:"🌐",pairs:["EUR/USD","GBP/USD","XAU/USD"]},ny:{label:"New York",emoji:"🇺🇸",pairs:["EUR/USD","GBP/USD","XAU/USD"]},tokyo:{label:"Tokyo",emoji:"🇯🇵",pairs:["XAU/USD"]},off:{label:"Low Activity",emoji:"🌙",pairs:[]}};
function getSess(){const h=new Date().getUTCHours();if(h>=7&&h<12)return"london";if(h>=12&&h<17)return"overlap";if(h>=17&&h<20)return"ny";if(h>=0&&h<9)return"tokyo";return"off";}
function getActivePairs(){const p=SESS[getSess()].pairs;return p.length?p:["XAU/USD","EUR/USD","GBP/USD"];}
function isHighProb(){return["london","overlap"].includes(getSess());}
function getScanMs(){const s=getSess();if(s==="london"||s==="overlap")return 2*60*1000;if(s==="ny"||s==="tokyo")return 4*60*1000;return 15*60*1000;}
function isPastClose(){return new Date().getUTCHours()>=DT.noTradeHour;}

// ══════════════════════════════════════════════════════════════════════════════
//  MATHS
// ══════════════════════════════════════════════════════════════════════════════
function ema(p,n){if(p.length<n)return null;const k=2/(n+1);let e=p.slice(0,n).reduce((a,b)=>a+b,0)/n;for(let i=n;i<p.length;i++)e=p[i]*k+e*(1-k);return e;}
function avg(a){return a.length?a.reduce((x,y)=>x+y,0)/a.length:0;}
function calcRSI(cls,period=14){if(cls.length<period+1)return 50;let g=0,l=0;for(let i=cls.length-period;i<cls.length;i++){const d=cls[i]-cls[i-1];if(d>0)g+=d;else l-=d;}return Math.round(100-(100/(1+(g/(l||0.001)))));}
function findSwings(cs,lb=3){const sH=[],sL=[];for(let i=lb;i<cs.length-lb;i++){const c=cs[i],lH=cs.slice(i-lb,i).map(x=>x.high),rH=cs.slice(i+1,i+lb+1).map(x=>x.high),lL=cs.slice(i-lb,i).map(x=>x.low),rL=cs.slice(i+1,i+lb+1).map(x=>x.low);if(c.high>Math.max(...lH,...rH))sH.push({i,price:c.high});if(c.low<Math.min(...lL,...rL))sL.push({i,price:c.low});}return{sH,sL};}
function findFVGs(cs){const f=[];for(let i=1;i<cs.length-1;i++){const p=cs[i-1],n=cs[i+1];if(p.high<n.low)f.push({type:"bull",top:n.low,bot:p.high,i});if(p.low>n.high)f.push({type:"bear",top:p.low,bot:n.high,i});}return f;}
function findOBs(cs){const o=[];for(let i=1;i<cs.length-2;i++){const c=cs[i],nx=cs[i+1],bs=Math.abs(nx.close-nx.open),ab=avg(cs.slice(Math.max(0,i-10),i).map(x=>Math.abs(x.close-x.open)));if(bs>ab*1.5){if(c.close<c.open&&nx.close>nx.open)o.push({type:"bull",top:c.open,bot:c.close,i});if(c.close>c.open&&nx.close<nx.open)o.push({type:"bear",top:c.close,bot:c.open,i});}}return o;}
function calcCVD(cs){let r=0;return cs.map(c=>{r+=(c.close-c.open)/((c.high-c.low)||1)*c.volume;return r;});}
function vspike(cs,idx,thr=1.5){const lb=cs.slice(Math.max(0,idx-20),idx);return lb.length>=5&&cs[idx].volume>avg(lb.map(c=>c.volume))*thr;}
function getBias(h4){if(h4.length<30)return"neutral";const cl=h4.map(c=>c.close),e20=ema(cl,Math.min(20,cl.length)),e50=ema(cl,Math.min(50,cl.length)),cur=cl[cl.length-1];if(!e20||!e50)return"neutral";if(cur>e20&&e20>e50)return"bullish";if(cur<e20&&e20<e50)return"bearish";return"neutral";}
function getBOS(h4){const{sH,sL}=findSwings(h4,3),last=h4[h4.length-1],rH=sH[sH.length-1],rL=sL[sL.length-1];if(rH&&last.close>rH.price)return"bullish";if(rL&&last.close<rL.price)return"bearish";return"none";}
function getDec(p){return p==="XAU/USD"?2:5;}

// ══════════════════════════════════════════════════════════════════════════════
//  RISK ENGINE
// ══════════════════════════════════════════════════════════════════════════════
function calcRisk({capital,riskPct,entry,sl,direction,pair,probMul=1}){
  const rAmt=(capital*riskPct)/100*probMul,slPips=Math.abs(entry-sl);if(!slPips)return null;
  const pipVal=10,slInPips=pair==="XAU/USD"?slPips/0.1:slPips/0.0001;
  const lots=Math.max(0.01,Math.floor((rAmt/(slInPips*pipVal))*100)/100);
  const dist=Math.abs(entry-sl),sign=direction==="BUY"?1:-1;
  const tp1=+(entry+sign*dist*2.5).toFixed(getDec(pair));
  const tp2=+(entry+sign*dist*3.5).toFixed(getDec(pair));
  const tp3=+(entry+sign*dist*5.0).toFixed(getDec(pair));
  const l1=Math.max(0.01,Math.floor(lots*50)/100),l2=Math.max(0.01,Math.floor((lots-l1)*100)/100);
  return{
    riskAmount:rAmt.toFixed(2),lots:lots.toFixed(2),lotsTP1:l1.toFixed(2),lotsRun:l2.toFixed(2),
    slInPips:slInPips.toFixed(1),
    tp1,tp2,tp3,rr1:"2.5",rr2:"3.5",rr3:"5.0",
    potProfit1:(slInPips*2.5*pipVal*lots).toFixed(2),
    potProfit2:(slInPips*3.5*pipVal*lots).toFixed(2),
    potProfit3:(slInPips*5.0*pipVal*lots).toFixed(2),
    profitTP1Half:(slInPips*2.5*pipVal*l1).toFixed(2),
    profitTP2Half:(slInPips*3.5*pipVal*l2).toFixed(2),
  };
}

// ══════════════════════════════════════════════════════════════════════════════
//  STRATEGY ENGINE
// ══════════════════════════════════════════════════════════════════════════════
function runStrategy(pair,{m5,m15,h4,price}){
  const bias=getBias(h4),bos=getBOS(h4);
  const sess=getSess(),inL=sess==="london",inO=sess==="overlap",inNY=sess==="ny",inSess=inL||inO||inNY;
  const sLbl=inL?"London open":inO?"London/NY":inNY?"New York":"Off-session";
  const li=m15.length-1,last=m15[li],prev=m15[li-1];
  const m5li=m5.length-1,m5last=m5[m5li],m5prev=m5[m5li-1];
  const closes=m15.map(c=>c.close);
  const currRSI=calcRSI(closes);
  const cvdArr=calcCVD(m15),l5c=cvdArr.slice(-5);
  const cvdUp=l5c[l5c.length-1]>l5c[0],cvdDn=l5c[l5c.length-1]<l5c[0];
  const rng=last.high-last.low;
  const pinBull=(Math.min(last.open,last.close)-last.low)>rng*0.55;
  const pinBear=(last.high-Math.max(last.open,last.close))>rng*0.55;
  const engBull=last.close>prev.high&&last.close>last.open;
  const engBear=last.close<prev.low&&last.close<last.open;
  const vs=vspike(m15,li,1.5),vsM5=vspike(m5,m5li,1.4);
  const m5Bull=m5last.close>m5prev.high&&m5last.close>m5last.open;
  const m5Bear=m5last.close<m5prev.low&&m5last.close<m5last.open;
  const rsiOver=currRSI<35,rsiUnder=currRSI>65;
  let sc=0;const rs=[],ck=[];
  if(bias!=="neutral"){sc+=18;ck.push("h4BiasAligned");}
  if(bos!=="none"&&bos===bias){sc+=14;ck.push("breakOfStructure");}
  if(inL){sc+=12;ck.push("londonSession");}else if(inO){sc+=14;ck.push("nyOverlap");}else if(inNY){sc+=10;ck.push("nyOverlap");}
  const m5momentum=(bias==="bullish"&&m5Bull)||(bias==="bearish"&&m5Bear);
  if(m5momentum){sc+=14;ck.push("intradayMomentum");}

  if(pair==="XAU/USD"){
    const vm={};m15.forEach(c=>{const k=Math.round(c.close/5)*5;vm[k]=(vm[k]||0)+c.volume;});
    const poc=Number(Object.entries(vm).sort((a,b)=>b[1]-a[1])[0][0]);
    const pdh=Math.max(...m15.slice(-60).map(c=>c.high)),pdl=Math.min(...m15.slice(-60).map(c=>c.low));
    const nr=Math.round(price/50)*50;
    const nPDH=Math.abs(price-pdh)<1.5,nPDL=Math.abs(price-pdl)<1.5,nPOC=Math.abs(price-poc)<1.5,nRnd=Math.abs(price-nr)<1.5;
    const conf=[nPDH||nPDL,nPOC,nRnd].filter(Boolean).length;
    if(bias==="bullish"){
      if(nPDL||nPOC){sc+=30;rs.push("Price at key support (PDL/POC)");ck.push("keyLevelConfluence");}
      if(nRnd){sc+=15;rs.push(`Round number $${nr}`);}
      if(conf>=2){sc+=8;rs.push("Multiple levels confluent");ck.push("multiConfluence");}
      if(vs){sc+=20;rs.push("Volume spike 150%+ on M15");ck.push("volumeSpike");}
      if(cvdUp){sc+=15;rs.push("CVD rising — buyers absorbing");ck.push("cvdDivergence");}
      if(pinBull||engBull){sc+=20;rs.push("Bullish rejection M15");ck.push("rejectionCandle");}
      if(m5Bull){sc+=12;rs.push("M5 engulfing confirms");ck.push("m5Confirmation");}
      if(rsiOver){sc+=10;rs.push(`RSI oversold (${currRSI})`);ck.push("rsiConfluence");}
      ck.push("cleanSL");
      if(sc>=DT.scoreThreshold){const sl=+(last.low-0.6).toFixed(2);return{signals:[{pair,direction:"BUY",entry:+price.toFixed(2),sl,score:sc,reasons:rs,ck,bias,session:sLbl,tf:"M15·M5",rsi:currRSI}],partialScore:sc,ck,bias};}
    }
    if(bias==="bearish"){
      if(nPDH||nPOC){sc+=30;rs.push("Price at key resistance (PDH/POC)");ck.push("keyLevelConfluence");}
      if(nRnd){sc+=15;rs.push(`Round number $${nr}`);}
      if(conf>=2){sc+=8;rs.push("Multiple levels confluent");ck.push("multiConfluence");}
      if(vs){sc+=20;rs.push("Volume spike 150%+");ck.push("volumeSpike");}
      if(cvdDn){sc+=15;rs.push("CVD falling — sellers dominant");ck.push("cvdDivergence");}
      if(pinBear||engBear){sc+=20;rs.push("Bearish rejection M15");ck.push("rejectionCandle");}
      if(m5Bear){sc+=12;rs.push("M5 confirms");ck.push("m5Confirmation");}
      if(rsiUnder){sc+=10;rs.push(`RSI overbought (${currRSI})`);ck.push("rsiConfluence");}
      ck.push("cleanSL");
      if(sc>=DT.scoreThreshold){const sl=+(last.high+0.6).toFixed(2);return{signals:[{pair,direction:"SELL",entry:+price.toFixed(2),sl,score:sc,reasons:rs,ck,bias,session:sLbl,tf:"M15·M5",rsi:currRSI}],partialScore:sc,ck,bias};}
    }
  }
  if(pair==="EUR/USD"){
    const obList=findOBs(m15),fvgList=findFVGs(m15);
    const inBOB=obList.some(o=>o.type==="bull"&&price>=o.bot&&price<=o.top&&li-o.i<50);
    const inBOBr=obList.some(o=>o.type==="bear"&&price>=o.bot&&price<=o.top&&li-o.i<50);
    const fBFVG=fvgList.some(f=>f.type==="bull"&&price>=f.bot&&price<=f.top&&li-f.i<30);
    const fBrFVG=fvgList.some(f=>f.type==="bear"&&price>=f.bot&&price<=f.top&&li-f.i<30);
    if(bias==="bullish"&&(inBOB||fBFVG)){
      if(inBOB){sc+=35;rs.push("Inside bullish order block");ck.push("orderBlock");}
      if(fBFVG){sc+=25;rs.push("Filling bullish FVG");ck.push("fairValueGap");}
      if(vs||vsM5){sc+=18;rs.push("Volume spike at structure");ck.push("volumeSpike");}
      if(engBull){sc+=20;rs.push("Bullish engulfing M15");ck.push("rejectionCandle");}
      if(m5Bull){sc+=12;rs.push("M5 confirms");ck.push("m5Confirmation");}
      if(cvdUp){sc+=15;rs.push("CVD rising at level");ck.push("cvdDivergence");}
      if(rsiOver){sc+=10;rs.push(`RSI ${currRSI} oversold`);ck.push("rsiConfluence");}
      ck.push("cleanSL");
      if(sc>=DT.scoreThreshold){const lo=Math.min(...m15.slice(-5).map(c=>c.low)),sl=+(lo-0.0005).toFixed(5);return{signals:[{pair,direction:"BUY",entry:+price.toFixed(5),sl,score:sc,reasons:rs,ck,bias,session:sLbl,tf:"M15·M5",rsi:currRSI}],partialScore:sc,ck,bias};}
    }
    if(bias==="bearish"&&(inBOBr||fBrFVG)){
      if(inBOBr){sc+=35;rs.push("Inside bearish order block");ck.push("orderBlock");}
      if(fBrFVG){sc+=25;rs.push("Filling bearish FVG");ck.push("fairValueGap");}
      if(vs||vsM5){sc+=18;rs.push("Volume spike at structure");ck.push("volumeSpike");}
      if(engBear){sc+=20;rs.push("Bearish engulfing M15");ck.push("rejectionCandle");}
      if(m5Bear){sc+=12;rs.push("M5 confirms");ck.push("m5Confirmation");}
      if(cvdDn){sc+=15;rs.push("CVD falling");ck.push("cvdDivergence");}
      if(rsiUnder){sc+=10;rs.push(`RSI ${currRSI} overbought`);ck.push("rsiConfluence");}
      ck.push("cleanSL");
      if(sc>=DT.scoreThreshold){const hi=Math.max(...m15.slice(-5).map(c=>c.high)),sl=+(hi+0.0005).toFixed(5);return{signals:[{pair,direction:"SELL",entry:+price.toFixed(5),sl,score:sc,reasons:rs,ck,bias,session:sLbl,tf:"M15·M5",rsi:currRSI}],partialScore:sc,ck,bias};}
    }
  }
  if(pair==="GBP/USD"){
    const{sH,sL}=findSwings(m15,3),li2=m15.length-1,sec=m15[li2-1],thi=m15[li2-2];
    const rSH=sH.slice(-3).find(s=>li2-s.i<10),rSL=sL.slice(-3).find(s=>li2-s.i<10);
    const swH=rSH&&(sec.high>rSH.price||thi.high>rSH.price)&&last.close<rSH.price;
    const swL=rSL&&(sec.low<rSL.price||thi.low<rSL.price)&&last.close>rSL.price;
    const swIdx=swH||swL?li2-1:null,vSw=swIdx!=null?vspike(m15,swIdx,1.4):false;
    const shBr=last.close<last.open&&(last.open-last.close)>rng*0.5,shBl=last.close>last.open&&(last.close-last.open)>rng*0.5;
    if(bias==="bearish"&&swH){
      sc+=40;rs.push("Liquidity sweep above swing high");ck.push("liquiditySweep");
      if(vSw){sc+=25;rs.push("High volume on sweep");ck.push("volumeSpike");}
      if(shBr){sc+=25;rs.push("Sharp bearish reversal");ck.push("rejectionCandle");}
      if(m5Bear){sc+=12;rs.push("M5 bearish confirm");ck.push("m5Confirmation");}
      if(cvdDn){sc+=15;rs.push("CVD falling");ck.push("cvdDivergence");}
      ck.push("cleanSL");
      if(sc>=DT.scoreThreshold){const sl=+(sec.high+0.0009).toFixed(5);return{signals:[{pair,direction:"SELL",entry:+price.toFixed(5),sl,score:sc,reasons:rs,ck,bias,session:sLbl,tf:"M5/M15",rsi:currRSI}],partialScore:sc,ck,bias};}
    }
    if(bias==="bullish"&&swL){
      sc+=40;rs.push("Liquidity sweep below swing low");ck.push("liquiditySweep");
      if(vSw){sc+=25;rs.push("High volume on sweep");ck.push("volumeSpike");}
      if(shBl){sc+=25;rs.push("Sharp bullish reversal");ck.push("rejectionCandle");}
      if(m5Bull){sc+=12;rs.push("M5 bullish confirm");ck.push("m5Confirmation");}
      if(cvdUp){sc+=15;rs.push("CVD rising");ck.push("cvdDivergence");}
      ck.push("cleanSL");
      if(sc>=DT.scoreThreshold){const sl=+(sec.low-0.0009).toFixed(5);return{signals:[{pair,direction:"BUY",entry:+price.toFixed(5),sl,score:sc,reasons:rs,ck,bias,session:sLbl,tf:"M5/M15",rsi:currRSI}],partialScore:sc,ck,bias};}
    }
  }
  return{signals:[],partialScore:sc,ck,bias};
}

// ══════════════════════════════════════════════════════════════════════════════
//  SOUND + NOTIFICATIONS
// ══════════════════════════════════════════════════════════════════════════════
async function askNotif(){if(!("Notification"in window))return false;if(Notification.permission==="granted")return true;return(await Notification.requestPermission())==="granted";}
function pushSignalNotif(sig){if(Notification.permission!=="granted")return;new Notification(`${sig.direction==="BUY"?"▲":"▼"} ${sig.pair} ${sig.direction} ${sig.prob}% — NgFX`,{body:`Entry ${sig.entry} · SL ${sig.sl}\nTP1 ${sig.calc?.tp1} · TP2 ${sig.calc?.tp2}\nMax hold ${DT.maxHoldMins/60}h · ${sig.reasons[0]}`,tag:sig.id});}
function playSound(dir){try{const ctx=new(window.AudioContext||window.webkitAudioContext)();const freqs=dir==="BUY"?[440,554,659]:[659,554,440];freqs.forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=f;o.type="sine";g.gain.setValueAtTime(0,ctx.currentTime+i*0.12);g.gain.linearRampToValueAtTime(0.18,ctx.currentTime+i*0.12+0.03);g.gain.linearRampToValueAtTime(0,ctx.currentTime+i*0.12+0.18);o.start(ctx.currentTime+i*0.12);o.stop(ctx.currentTime+i*0.12+0.22);});}catch(e){}}
function playTPSound(){try{const ctx=new(window.AudioContext||window.webkitAudioContext)();[523,659,784,1047].forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=f;o.type="sine";g.gain.setValueAtTime(0,ctx.currentTime+i*0.1);g.gain.linearRampToValueAtTime(0.2,ctx.currentTime+i*0.1+0.04);g.gain.linearRampToValueAtTime(0,ctx.currentTime+i*0.1+0.2);o.start(ctx.currentTime+i*0.1);o.stop(ctx.currentTime+i*0.1+0.25);});}catch(e){}}
function playSLSound(){try{const ctx=new(window.AudioContext||window.webkitAudioContext)();[330,277,220].forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=f;o.type="sawtooth";g.gain.setValueAtTime(0.15,ctx.currentTime+i*0.15);g.gain.linearRampToValueAtTime(0,ctx.currentTime+i*0.15+0.25);o.start(ctx.currentTime+i*0.15);o.stop(ctx.currentTime+i*0.15+0.3);});}catch(e){}}

// ══════════════════════════════════════════════════════════════════════════════
//  LICENSE GATE SCREEN
// ══════════════════════════════════════════════════════════════════════════════
function LicenseScreen({onUnlock}){
  const[key,setKey]=useState(""),result=useState(null),setResult=result[1],res=result[0];
  const[loading,setLoading]=useState(false);
  const check=()=>{
    setLoading(true);
    setTimeout(()=>{
      const v=validateLicense(key);
      setResult(v);
      if(v.valid){saveLicense(key);setTimeout(()=>onUnlock(v),800);}
      setLoading(false);
    },600);
  };
  return(
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"2rem",fontFamily:FD}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;700;800;900&family=JetBrains+Mono:wght@400;700;800&display=swap');*{box-sizing:border-box}`}</style>
      {/* Logo */}
      <div style={{marginBottom:32,textAlign:"center"}}>
        <svg width="72" height="72" viewBox="0 0 44 44" fill="none" style={{marginBottom:16}}>
          <rect width="44" height="44" rx="12" fill="url(#lgBg2)" opacity="0.95"/>
          <rect width="44" height="44" rx="12" fill="none" stroke="rgba(240,180,41,0.5)" strokeWidth="1.5"/>
          <rect x="8" y="16" width="5" height="15" rx="1.5" fill={C.green}/><line x1="10.5" y1="11" x2="10.5" y2="16" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/><line x1="10.5" y1="31" x2="10.5" y2="35" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/>
          <rect x="17" y="20" width="5" height="11" rx="1.5" fill={C.red}/><line x1="19.5" y1="14" x2="19.5" y2="20" stroke={C.red} strokeWidth="1.5" strokeLinecap="round"/><line x1="19.5" y1="31" x2="19.5" y2="35" stroke={C.red} strokeWidth="1.5" strokeLinecap="round"/>
          <rect x="26" y="12" width="5" height="19" rx="1.5" fill={C.green}/><line x1="28.5" y1="8" x2="28.5" y2="12" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/><line x1="28.5" y1="31" x2="28.5" y2="36" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M7 36 Q15 28 22 30 Q29 32 37 20" stroke={C.gold} strokeWidth="1.8" fill="none" strokeLinecap="round"/>
          <circle cx="37" cy="20" r="2.5" fill={C.gold}/>
          <defs><linearGradient id="lgBg2" x1="0" y1="0" x2="44" y2="44"><stop offset="0%" stopColor="rgba(240,180,41,0.18)"/><stop offset="100%" stopColor="rgba(8,12,24,0.95)"/></linearGradient></defs>
        </svg>
        <div style={{display:"flex",alignItems:"baseline",justifyContent:"center",gap:2}}>
          <span style={{fontSize:38,fontWeight:900,color:C.goldLight,letterSpacing:"-0.04em",textShadow:`0 0 30px ${C.goldGlow}`}}>Ng</span>
          <span style={{fontSize:38,fontWeight:900,color:C.text,letterSpacing:"-0.04em"}}>FX</span>
        </div>
        <div style={{fontSize:11,color:C.textMuted,letterSpacing:"0.18em",textTransform:"uppercase",fontFamily:FM,marginTop:4}}>Orderflow Signal Engine</div>
        <div style={{fontSize:11,color:C.textMuted,marginTop:6,fontFamily:FM}}>by Nguruh</div>
      </div>

      <div style={{width:"100%",maxWidth:340,background:"rgba(255,255,255,0.03)",border:`1px solid ${C.gold}33`,borderRadius:20,padding:"1.6rem",backdropFilter:"blur(20px)",boxShadow:`0 0 40px ${C.goldGlow}`}}>
        <div style={{fontSize:14,fontWeight:700,color:C.text,marginBottom:6,fontFamily:FD}}>Enter your license key</div>
        <div style={{fontSize:11,color:C.textMuted,marginBottom:18,fontFamily:FM,lineHeight:1.6}}>Purchase a key from Nguruh to access NgFX. Keys are valid for 30 days.</div>
        <input
          value={key} onChange={e=>setKey(e.target.value.toUpperCase())}
          onKeyDown={e=>e.key==="Enter"&&check()}
          placeholder="NGFX-YYYYMMDD-XXXXXXXX"
          style={{width:"100%",padding:"13px 14px",background:"rgba(255,255,255,0.05)",border:`1px solid ${res?.valid===false?C.red+"66":res?.valid?C.green+"66":C.glassBorder}`,borderRadius:12,color:C.text,fontSize:14,fontFamily:FM,outline:"none",boxSizing:"border-box",marginBottom:10,letterSpacing:"0.04em"}}
        />
        {res&&(
          <div style={{fontSize:11,fontFamily:FM,marginBottom:12,padding:"8px 12px",borderRadius:10,background:res.valid?C.greenDeep:C.redDeep,color:res.valid?C.green:C.red,border:`1px solid ${res.valid?C.green:C.red}33`}}>
            {res.valid?`✓ Valid · ${res.daysLeft} days remaining · Expires ${res.expDate}`:res.reason}
          </div>
        )}
        <button onClick={check} disabled={!key.trim()||loading} style={{width:"100%",padding:"13px",background:loading?"rgba(255,255,255,0.06)":`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:loading?C.textMuted:"#1a1000",border:"none",borderRadius:12,cursor:!key.trim()||loading?"not-allowed":"pointer",fontSize:13,fontWeight:800,fontFamily:FD,transition:"all 0.2s",boxShadow:loading?"none":`0 6px 20px ${C.goldGlow}`}}>
          {loading?"Validating…":"Unlock NgFX"}
        </button>
        <div style={{marginTop:18,fontSize:10,color:C.textMuted,textAlign:"center",fontFamily:FM,lineHeight:1.7}}>
          To purchase a key, contact <span style={{color:C.gold}}>Nguruh</span> directly.<br/>Keys work on any device — install on Android via Chrome → Add to Home Screen.
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  MINI CHART COMPONENT
// ══════════════════════════════════════════════════════════════════════════════
function MiniChart({pair,candles,price,partialScore,minScore,ck,rsiVal,bias,latestSignal}){
  const W=340,H=130,VH=24,PAD=4,N=30;
  const shown=candles?candles.slice(-N):[];
  if(!shown.length)return(
    <div style={{background:C.chart,borderRadius:14,padding:"2.5rem",textAlign:"center",border:`1px solid ${C.border}`}}>
      <div style={{fontSize:11,color:C.textMuted,fontFamily:FM,animation:"shimmer 2s infinite"}}>Loading chart data…</div>
    </div>
  );
  const highs=shown.map(c=>c.high),lows=shown.map(c=>c.low);
  const maxP=Math.max(...highs,price||0),minP=Math.min(...lows,price||999999);
  const range=maxP-minP||0.001;
  const toY=v=>PAD+(1-(v-minP)/range)*(H-PAD*2);
  const cW=(W-16)/N,gap=1;
  const closes=shown.map(c=>c.close);
  const ema20pts=closes.map((cl,i)=>{const e=ema(closes.slice(0,i+1),Math.min(20,i+1));return e?`${8+i*cW+cW/2},${toY(e)}`:null;}).filter(Boolean);
  const ema50pts=closes.map((cl,i)=>{const e=ema(closes.slice(0,i+1),Math.min(50,i+1));return e?`${8+i*cW+cW/2},${toY(e)}`:null;}).filter(Boolean);
  const maxVol=Math.max(...shown.map(c=>c.volume),1);
  const formPct=Math.min(100,Math.round((partialScore/115)*100));
  const threshPct=Math.round((minScore/115)*100);
  const formColor=formPct>=threshPct?C.green:formPct>=threshPct*0.65?C.amber:C.blue;
  const formLabel=formPct>=threshPct?"🔥 Signal ready":formPct>=threshPct*0.65?"⚡ Setup forming":formPct>=20?"👁 Watching":"Scanning";
  const pairC=pair==="XAU/USD"?C.gold:pair==="EUR/USD"?C.blue:C.purple;
  const dirC=latestSignal?.direction==="BUY"?C.green:latestSignal?.direction==="SELL"?C.red:null;
  const currPrice=price||(closes[closes.length-1]);
  const priceChange=closes.length>1?((closes[closes.length-1]-closes[0])/closes[0]*100).toFixed(2):0;
  const rsi=rsiVal||50,rsiC=rsi<35?C.green:rsi>65?C.red:C.textMuted;

  return(
    <div style={{background:C.chart,borderRadius:16,overflow:"hidden",border:`1px solid ${latestSignal?dirC+"55":pairC+"28"}`,boxShadow:latestSignal?`0 0 20px ${dirC}22`:"none",transition:"box-shadow 0.4s"}}>
      {/* Chart header */}
      <div style={{padding:"9px 12px 0",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
            <span style={{fontSize:13,fontWeight:800,color:pairC,fontFamily:FM}}>{pair}</span>
            <span style={{fontSize:13,fontWeight:700,color:C.text,fontFamily:FM}}>{pair==="XAU/USD"?currPrice?.toFixed(2):currPrice?.toFixed(5)}</span>
            <span style={{fontSize:10,color:parseFloat(priceChange)>=0?C.green:C.red,fontFamily:FM}}>{parseFloat(priceChange)>=0?"+":""}{priceChange}%</span>
          </div>
          <div style={{display:"flex",gap:6,alignItems:"center"}}>
            {bias&&<span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:bias==="bullish"?C.greenDeep:C.redDeep,color:bias==="bullish"?C.green:C.red,fontFamily:FM}}>{bias}</span>}
            <span style={{fontSize:9,color:rsiC,fontFamily:FM}}>RSI {rsi}</span>
            {USE_LIVE_DATA&&<span style={{fontSize:8,color:C.green,fontFamily:FM}}>● LIVE</span>}
          </div>
        </div>
        {latestSignal&&(
          <span style={{fontSize:11,fontWeight:800,color:dirC,fontFamily:FM,background:`${dirC}18`,padding:"4px 10px",borderRadius:99,border:`1px solid ${dirC}44`}}>{latestSignal.direction==="BUY"?"▲":"▼"} {latestSignal.direction}</span>
        )}
      </div>

      {/* Formation bar */}
      <div style={{padding:"6px 12px 4px"}}>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:C.textMuted,marginBottom:3,fontFamily:FM}}>
          <span style={{color:formColor,fontWeight:700}}>{formLabel}</span>
          <span>{formPct}% formed</span>
        </div>
        <div style={{height:3,background:"rgba(255,255,255,0.05)",borderRadius:99,overflow:"hidden",position:"relative"}}>
          <div style={{position:"absolute",top:0,left:`${threshPct}%`,width:1,height:"100%",background:"rgba(255,255,255,0.25)"}}/>
          <div style={{height:"100%",width:`${formPct}%`,background:formColor,borderRadius:99,transition:"width 0.9s ease",boxShadow:`0 0 5px ${formColor}55`}}/>
        </div>
        {ck.length>0&&(
          <div style={{display:"flex",gap:4,marginTop:5,flexWrap:"wrap"}}>
            {ck.slice(0,6).map(k=><span key={k} style={{fontSize:7.5,padding:"1px 5px",borderRadius:99,background:`${pairC}18`,color:pairC,fontFamily:FM,border:`1px solid ${pairC}28`}}>{CW[k]?.label||k}</span>)}
            {ck.length>6&&<span style={{fontSize:7.5,color:C.textMuted,fontFamily:FM}}>+{ck.length-6}</span>}
          </div>
        )}
      </div>

      {/* SVG Chart */}
      <svg width="100%" viewBox={`0 0 ${W} ${H+VH+6}`} style={{display:"block"}}>
        {[0.25,0.5,0.75].map(f=><line key={f} x1="8" y1={PAD+(1-f)*(H-PAD*2)} x2={W-4} y2={PAD+(1-f)*(H-PAD*2)} stroke="rgba(255,255,255,0.03)" strokeWidth="0.5"/>)}
        {ema20pts.length>1&&<polyline points={ema20pts.join(" ")} fill="none" stroke={C.amber} strokeWidth="1" opacity="0.65"/>}
        {ema50pts.length>1&&<polyline points={ema50pts.join(" ")} fill="none" stroke={C.purple} strokeWidth="1" opacity="0.45"/>}
        {currPrice&&<line x1="8" y1={toY(currPrice)} x2={W-4} y2={toY(currPrice)} stroke={pairC} strokeWidth="0.6" strokeDasharray="3 3" opacity="0.5"/>}
        {/* TP/SL lines if signal active */}
        {latestSignal?.calc&&(()=>{
          const{tp1,tp2,sl}=latestSignal.calc;
          return(<>
            <line x1="8" y1={toY(tp1)} x2={W-4} y2={toY(tp1)} stroke={C.green} strokeWidth="0.8" strokeDasharray="4 2" opacity="0.6"/>
            <line x1="8" y1={toY(tp2)} x2={W-4} y2={toY(tp2)} stroke={C.green} strokeWidth="0.8" strokeDasharray="4 2" opacity="0.4"/>
            <line x1="8" y1={toY(sl)}  x2={W-4} y2={toY(sl)}  stroke={C.red}   strokeWidth="0.8" strokeDasharray="4 2" opacity="0.6"/>
            <text x={W-6} y={toY(tp1)-3} fontSize="7" fill={C.green} textAnchor="end" fontFamily={FM} opacity="0.8">TP1</text>
            <text x={W-6} y={toY(tp2)-3} fontSize="7" fill={C.green} textAnchor="end" fontFamily={FM} opacity="0.6">TP2</text>
            <text x={W-6} y={toY(sl)-3}  fontSize="7" fill={C.red}   textAnchor="end" fontFamily={FM} opacity="0.8">SL</text>
          </>);
        })()}
        {shown.map((c,i)=>{
          const x=8+i*cW+gap,bW=Math.max(1.5,cW-gap*2),isBull=c.close>=c.open,col=isBull?C.green:C.red;
          const bodyTop=toY(Math.max(c.open,c.close)),bodyBot=toY(Math.min(c.open,c.close)),bodyH=Math.max(1,bodyBot-bodyTop),midX=x+bW/2;
          return(<g key={i}><line x1={midX} y1={toY(c.high)} x2={midX} y2={toY(c.low)} stroke={col} strokeWidth="0.7" opacity="0.65"/><rect x={x} y={bodyTop} width={bW} height={bodyH} fill={col} opacity={isBull?0.88:0.78} rx="0.5"/></g>);
        })}
        {latestSignal&&(
          latestSignal.direction==="BUY"
            ?<polygon points={`${W-18},${H-10} ${W-10},${H-22} ${W-2},${H-10}`} fill={C.green} opacity="0.85"/>
            :<polygon points={`${W-18},${H-22} ${W-10},${H-10} ${W-2},${H-22}`} fill={C.red}   opacity="0.85"/>
        )}
        {shown.map((c,i)=>{const x=8+i*cW+gap,bW=Math.max(1.5,cW-gap*2),vH=(c.volume/maxVol)*VH,isBull=c.close>=c.open;return(<rect key={`v${i}`} x={x} y={H+VH-vH} width={bW} height={vH} fill={isBull?C.green:C.red} opacity="0.32" rx="0.4"/>);})}
        <rect x="10" y={H+VH+1} width="8" height="2" fill={C.amber} rx="1"/>
        <text x="20" y={H+VH+4.5} fontSize="6.5" fill={C.textMuted} fontFamily={FM}>EMA20</text>
        <rect x="58" y={H+VH+1} width="8" height="2" fill={C.purple} rx="1"/>
        <text x="68" y={H+VH+4.5} fontSize="6.5" fill={C.textMuted} fontFamily={FM}>EMA50</text>
      </svg>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  SIGNAL CARD
// ══════════════════════════════════════════════════════════════════════════════
function SignalCard({sig,onDismiss,onMark}){
  const isBuy=sig.direction==="BUY",dirC=isBuy?C.green:C.red,dirDeep=isBuy?C.greenDeep:C.redDeep;
  const pairC=sig.pair==="XAU/USD"?C.gold:sig.pair==="EUR/USD"?C.blue:C.purple;
  const pairGlow=sig.pair==="XAU/USD"?C.goldGlow:sig.pair==="EUR/USD"?C.blueGlow:C.purpleGlow;
  const c=sig.calc,pCol=probColor(sig.prob);
  const[mLeft,setML]=useState(()=>Math.max(0,DT.maxHoldMins-Math.floor((Date.now()-sig.createdAt)/60000)));
  useEffect(()=>{const i=setInterval(()=>setML(m=>Math.max(0,m-1)),60000);return()=>clearInterval(i);},[]);
  const expired=mLeft===0&&!sig.result;
  const closeBy=new Date(sig.createdAt+DT.maxHoldMins*60*1000).toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit"});

  return(
    <div style={{background:"rgba(8,12,22,0.88)",border:`1px solid ${expired?"rgba(255,255,255,0.05)":dirC+"28"}`,borderRadius:20,marginBottom:14,overflow:"hidden",backdropFilter:"blur(20px)",boxShadow:`0 4px 24px rgba(0,0,0,0.5),0 0 50px ${expired?"transparent":isBuy?C.greenGlow:C.redGlow}`,opacity:expired?0.4:1,transition:"opacity 0.5s"}}>
      <div style={{height:2,background:expired?"rgba(255,255,255,0.04)":`linear-gradient(90deg,${dirC},${pairC},transparent)`}}/>
      <div style={{padding:"1rem 1rem 0.9rem"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:11}}>
          <div style={{flex:1}}>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8,flexWrap:"wrap"}}>
              <div style={{display:"inline-flex",alignItems:"center",gap:5,background:pairGlow,border:`1px solid ${pairC}33`,borderRadius:8,padding:"3px 9px"}}><div style={{width:5,height:5,borderRadius:"50%",background:pairC}}/><span style={{fontSize:10,fontWeight:700,color:pairC,fontFamily:FM}}>{sig.pair}</span></div>
              <span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:"rgba(96,165,250,0.07)",color:C.blue,fontFamily:FM,border:`1px solid ${C.blue}28`}}>📊 Day trade</span>
              <span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:"rgba(255,255,255,0.04)",color:expired?C.red:mLeft<30?C.amber:C.textMuted,fontFamily:FM}}>{expired?"Expired":`⏱ ${mLeft}m · close by ${closeBy}`}</span>
              {sig.result&&<span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:sig.result==="win"?C.greenDeep:C.redDeep,color:sig.result==="win"?C.green:C.red,fontFamily:FM,fontWeight:700}}>{sig.result==="win"?"✓ Win":"✗ Loss"}</span>}
              {/* TP/SL hit badges */}
              {sig.tp1Hit&&<span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:C.greenDeep,color:C.green,fontFamily:FM}}>🎯 TP1 hit</span>}
              {sig.tp2Hit&&<span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:C.greenDeep,color:C.green,fontFamily:FM}}>🎯🎯 TP2 hit</span>}
              {sig.slHit&&<span style={{fontSize:9,padding:"2px 7px",borderRadius:99,background:C.redDeep,color:C.red,fontFamily:FM}}>⛔ SL hit</span>}
              <span style={{fontSize:8,color:C.textMuted,fontFamily:FM,opacity:0.4,marginLeft:"auto"}}>NgFX·Nguruh</span>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:24,fontWeight:900,color:dirC,fontFamily:FD,letterSpacing:"-0.02em",textShadow:`0 0 18px ${dirC}55`}}>{isBuy?"▲ BUY":"▼ SELL"}</span>
              <div style={{position:"relative",width:44,height:44,flexShrink:0}}>
                {(()=>{const col=sig.score>=90?C.green:sig.score>=70?C.amber:C.gold,r=16,circ=2*Math.PI*r,dash=Math.min(sig.score/115,1)*circ;return(<><svg width="44" height="44" style={{transform:"rotate(-90deg)"}}><circle cx="22" cy="22" r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="3"/><circle cx="22" cy="22" r={r} fill="none" stroke={col} strokeWidth="3" strokeDasharray={`${dash} ${circ-dash}`} strokeLinecap="round"/></svg><div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontSize:10,fontWeight:800,color:col,fontFamily:FM}}>{sig.score}</span></div></>);})()}
              </div>
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:7}}>
            <button onClick={onDismiss} style={{width:26,height:26,borderRadius:"50%",background:"rgba(255,255,255,0.04)",border:"none",color:C.textMuted,cursor:"pointer",fontSize:13,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
            {(()=>{const col=probColor(sig.prob),r=22,circ=2*Math.PI*r,dash=(sig.prob/100)*circ;return(<div style={{position:"relative",width:60,height:60,flexShrink:0}}><svg width="60" height="60" style={{transform:"rotate(-90deg)"}}><circle cx="30" cy="30" r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="4"/><circle cx="30" cy="30" r={r} fill="none" stroke={col} strokeWidth="4" strokeDasharray={`${dash} ${circ-dash}`} strokeLinecap="round" style={{filter:`drop-shadow(0 0 4px ${col}88)`}}/></svg><div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:1}}><span style={{fontSize:14,fontWeight:900,color:col,fontFamily:FM,lineHeight:1}}>{sig.prob}%</span><span style={{fontSize:7,color:col,opacity:0.7,fontFamily:FM}}>WIN</span></div></div>);})()}
          </div>
        </div>

        {/* Probability badges */}
        <div style={{background:`${pCol}0c`,border:`1px solid ${pCol}30`,borderRadius:12,padding:"9px 12px",marginBottom:9}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
            <span style={{fontSize:10,color:pCol,fontWeight:700,fontFamily:FM,textTransform:"uppercase",letterSpacing:"0.07em"}}>{probLabel(sig.prob)}</span>
            <span style={{fontSize:10,color:C.textMuted,fontFamily:FM}}>Lots ×{Math.round(probMult(sig.prob)*100)}% · RSI {sig.rsi}</span>
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
            {sig.ck?.map(k=><span key={k} style={{fontSize:8,padding:"2px 6px",borderRadius:99,background:`${pCol}14`,color:pCol,fontFamily:FM,border:`1px solid ${pCol}28`}}>{CW[k]?.label||k} +{CW[k]?.weight||0}</span>)}
          </div>
        </div>

        {/* Levels */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7,marginBottom:8}}>
          {[{label:"Entry",val:sig.entry,col:C.text,bg:"rgba(255,255,255,0.04)"},{label:"Stop loss",val:sig.sl,col:C.red,bg:C.redDeep}].map(({label,val,col,bg})=>(
            <div key={label} style={{background:bg,borderRadius:12,padding:"10px 13px",border:`1px solid ${col}1a`}}>
              <div style={{fontSize:9,color:C.textMuted,marginBottom:4,textTransform:"uppercase",letterSpacing:"0.07em",fontFamily:FM}}>{label}</div>
              <div style={{fontSize:15,fontWeight:800,color:col,fontFamily:FM}}>{val}</div>
            </div>
          ))}
        </div>

        {/* 3 TPs */}
        {c&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:7,marginBottom:8}}>
          {[{l:"TP1",rr:c.rr1,v:c.tp1,p:c.potProfit1,hit:sig.tp1Hit},{l:"TP2",rr:c.rr2,v:c.tp2,p:c.potProfit2,hit:sig.tp2Hit},{l:"TP3",rr:c.rr3,v:c.tp3,p:c.potProfit3,hit:sig.tp3Hit}].map(({l,rr,v,p,hit},i)=>(
            <div key={l} style={{background:hit?C.greenDeep:`rgba(52,211,153,${0.04+i*0.02})`,borderRadius:12,padding:"9px 9px",border:`1px solid ${hit?C.green+"66":C.green+(i===2?"33":"1a")}`,textAlign:"center",transition:"all 0.3s"}}>
              <div style={{fontSize:8,color:hit?C.green:C.green,fontFamily:FM,opacity:hit?1:0.7}}>{l} · 1:{rr} {hit?"✓":""}</div>
              <div style={{fontSize:11,fontWeight:800,color:C.green,fontFamily:FM,marginTop:2,wordBreak:"break-all"}}>{v}</div>
              <div style={{fontSize:10,color:C.green,opacity:0.75,marginTop:1}}>+${p}</div>
            </div>
          ))}
        </div>}

        {/* Partial close + risk */}
        {c&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7,marginBottom:8}}>
          <div style={{background:"rgba(251,191,36,0.05)",border:`1px solid ${C.amber}22`,borderRadius:12,padding:"9px 12px"}}>
            <div style={{fontSize:9,color:C.amber,fontFamily:FM,marginBottom:4,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.06em"}}>Partial close</div>
            <div style={{fontSize:11,color:C.amber,fontFamily:FM}}>Close {c.lotsTP1} lots at TP1</div>
            <div style={{fontSize:10,color:C.textMuted,fontFamily:FM}}>Lock +${c.profitTP1Half}</div>
            <div style={{fontSize:11,color:C.green,fontFamily:FM,marginTop:3}}>Run {c.lotsRun} → TP2/3</div>
          </div>
          <div style={{background:"rgba(255,255,255,0.02)",border:`1px solid ${C.border}`,borderRadius:12,padding:"9px 12px"}}>
            <div style={{fontSize:9,color:C.textMuted,fontFamily:FM,marginBottom:4,textTransform:"uppercase",letterSpacing:"0.06em"}}>Risk</div>
            <div style={{fontSize:11,color:C.amber,fontFamily:FM}}>${c.riskAmount}</div>
            <div style={{fontSize:11,color:C.text,fontFamily:FM}}>Lots: {c.lots}</div>
            <div style={{fontSize:11,color:C.textMuted,fontFamily:FM}}>SL: {c.slInPips} pips</div>
          </div>
        </div>}

        <div style={{background:"rgba(96,165,250,0.05)",border:`1px solid ${C.blue}22`,borderRadius:10,padding:"7px 11px",marginBottom:9,display:"flex",gap:7,alignItems:"center"}}>
          <span style={{fontSize:11}}>📊</span>
          <span style={{fontSize:10,color:C.blue,fontFamily:FM}}>Intraday only — close by {closeBy} UTC · {sig.tf}</span>
        </div>

        <div style={{borderTop:`1px solid rgba(255,255,255,0.04)`,paddingTop:10,marginBottom:10}}>
          <div style={{fontSize:9,color:C.textMuted,marginBottom:6,textTransform:"uppercase",letterSpacing:"0.07em",fontFamily:FM}}>Signal conditions</div>
          {sig.reasons.map((r,i)=>(
            <div key={i} style={{display:"flex",gap:7,marginBottom:5,alignItems:"flex-start"}}>
              <div style={{width:15,height:15,borderRadius:"50%",background:dirDeep,border:`1px solid ${dirC}44`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}><span style={{fontSize:7,color:dirC,fontWeight:900}}>✓</span></div>
              <span style={{fontSize:11,color:C.textSub,lineHeight:1.55}}>{r}</span>
            </div>
          ))}
        </div>

        {!sig.result&&!expired&&(
          <div style={{display:"flex",gap:7,marginBottom:6}}>
            <button onClick={()=>onMark(sig.id,"win")}  style={{flex:1,padding:"8px",background:C.greenDeep,border:`1px solid ${C.green}44`,borderRadius:10,color:C.green,cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:FM}}>✓ Win</button>
            <button onClick={()=>onMark(sig.id,"loss")} style={{flex:1,padding:"8px",background:C.redDeep,  border:`1px solid ${C.red}44`,  borderRadius:10,color:C.red,  cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:FM}}>✗ Loss</button>
          </div>
        )}
        <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
          {[sig.tf,sig.bias+" bias",sig.time].map(t=><span key={t} style={{fontSize:9,padding:"3px 8px",borderRadius:99,background:"rgba(255,255,255,0.03)",color:C.textMuted,border:`1px solid ${C.border}`,fontFamily:FM,textTransform:"capitalize"}}>{t}</span>)}
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  ANALYTICS
// ══════════════════════════════════════════════════════════════════════════════
function Analytics({history}){
  const total=history.length,wins=history.filter(s=>s.result==="win").length,losses=history.filter(s=>s.result==="loss").length,marked=wins+losses,wr=marked?Math.round((wins/marked)*100):0;
  const PAIRS=["XAU/USD","EUR/USD","GBP/USD"];
  const pStats=PAIRS.map(p=>{const ph=history.filter(s=>s.pair===p),pw=ph.filter(s=>s.result==="win").length,pm=ph.filter(s=>s.result).length;return{pair:p,total:ph.length,wr:pm?Math.round((pw/pm)*100):null};});
  let eq=0;const equity=history.slice().reverse().map(s=>{if(s.result==="win")eq+=parseFloat(s.calc?.potProfit2||0);if(s.result==="loss")eq-=parseFloat(s.calc?.riskAmount||0);return+eq.toFixed(2);});
  const eqMin=Math.min(...equity,0),eqMax=Math.max(...equity,1),eqR=eqMax-eqMin||1;
  const W=320,H=80,pts=equity.map((v,i)=>`${(i/(equity.length-1||1))*W},${H-((v-eqMin)/eqR)*H}`).join(" ");
  return(
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:14}}>
        {[{l:"Total",v:total,c:C.text},{l:"Wins",v:wins,c:C.green},{l:"Losses",v:losses,c:C.red},{l:"Win %",v:marked?`${wr}%`:"—",c:wr>=60?C.green:wr>=45?C.amber:C.red}].map(({l,v,c})=>(
          <div key={l} style={{background:"rgba(255,255,255,0.03)",border:`1px solid ${C.border}`,borderRadius:14,padding:"12px 8px",textAlign:"center"}}><div style={{fontSize:9,color:C.textMuted,marginBottom:4,textTransform:"uppercase",letterSpacing:"0.07em",fontFamily:FM}}>{l}</div><div style={{fontSize:19,fontWeight:900,color:c,fontFamily:FD}}>{v}</div></div>
        ))}
      </div>
      {equity.length>1&&<div style={{background:"rgba(255,255,255,0.02)",border:`1px solid ${C.border}`,borderRadius:14,padding:"12px",marginBottom:12}}>
        <div style={{fontSize:10,color:C.textMuted,textTransform:"uppercase",letterSpacing:"0.07em",fontFamily:FM,marginBottom:8}}>Equity curve</div>
        <svg width="100%" viewBox={`0 0 ${W} ${H+8}`} style={{overflow:"visible"}}><polyline points={pts} fill="none" stroke={eq>=0?C.green:C.red} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><line x1="0" y1={H-((0-eqMin)/eqR)*H} x2={W} y2={H-((0-eqMin)/eqR)*H} stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" strokeDasharray="4 4"/></svg>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.textMuted,fontFamily:FM,marginTop:4}}><span>Start</span><span style={{color:eq>=0?C.green:C.red,fontWeight:700}}>{eq>=0?"+":""}{eq.toFixed(2)} USD</span><span>Now</span></div>
      </div>}
      <div style={{background:"rgba(255,255,255,0.02)",border:`1px solid ${C.border}`,borderRadius:14,padding:"12px"}}>
        <div style={{fontSize:10,color:C.textMuted,textTransform:"uppercase",letterSpacing:"0.07em",fontFamily:FM,marginBottom:10}}>Win rate by pair</div>
        {pStats.map(({pair,total:t,wr:w})=>{const clr=pair==="XAU/USD"?C.gold:pair==="EUR/USD"?C.blue:C.purple;return(<div key={pair} style={{marginBottom:10}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:11,fontWeight:700,color:clr,fontFamily:FM}}>{pair}</span><span style={{fontSize:11,color:w===null?C.textMuted:w>=60?C.green:w>=45?C.amber:C.red,fontFamily:FM,fontWeight:700}}>{w===null?"No data":`${w}%`} <span style={{color:C.textMuted,fontWeight:400}}>({t})</span></span></div><div style={{height:4,background:"rgba(255,255,255,0.05)",borderRadius:99,overflow:"hidden"}}><div style={{height:"100%",width:`${w||0}%`,background:clr,borderRadius:99}}/></div></div>);})}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  MAIN APP
// ══════════════════════════════════════════════════════════════════════════════
const PAIRS=["XAU/USD","EUR/USD","GBP/USD"];

function MainApp({license}){
  const[signals,   setSignals]  =useState([]);
  const[history,   setHistory]  =useState([]);
  const[tab,       setTab]      =useState("charts");
  const[notifPerm, setNotifPerm]=useState(typeof Notification!=="undefined"?Notification.permission:"default");
  const[scanCount, setScanCount]=useState(0);
  const[secsLeft,  setSecsLeft] =useState(0);
  const[iMs,       setIMs]      =useState(getScanMs());
  const[showCap,   setShowCap]  =useState(false);
  const[capital,   setCapital]  =useState(1000);
  const[riskPct,   setRiskPct]  =useState(1);
  const[dailyLimit,setDailyLimit]=useState(3);
  const[minScore,  setMinScore] =useState(60);
  const[soundOn,   setSoundOn]  =useState(true);
  const[tgUrl,     setTgUrl]    =useState("");
  const[dailyPnl,  setDailyPnl]=useState(0);
  const[ns,        setNs]       =useState({blocked:false});
  const[chartData, setChartData]=useState({});
  const[formation, setFormation]=useState({});
  const[dataSource,setDataSource]=useState(USE_LIVE_DATA?"live":"demo");
  const intRef=useRef(null),cntRef=useRef(null),secsRef=useRef(0);

  useEffect(()=>{const u=()=>setNs(getNews());u();const i=setInterval(u,60000);return()=>clearInterval(i);},[]);

  // Midnight reset
  useEffect(()=>{const now=new Date(),ms=(24*3600*1000)-((now.getUTCHours()*3600+now.getUTCMinutes()*60+now.getUTCSeconds())*1000);const t=setTimeout(()=>setDailyPnl(0),ms);return()=>clearTimeout(t);},[]);

  const limitReached=useCallback(()=>{if(!dailyLimit)return false;return dailyPnl<=-((capital*dailyLimit)/100);},[dailyPnl,capital,dailyLimit]);

  const attachCalc=useCallback((sig)=>{
    const prob=calcProb(sig.ck||[]);
    const calc=calcRisk({capital,riskPct,entry:sig.entry,sl:sig.sl,direction:sig.direction,pair:sig.pair,probMul:probMult(prob)});
    return{...sig,prob,calc};
  },[capital,riskPct]);

  const sendTg=useCallback(async(sig)=>{
    if(!tgUrl)return;
    try{const msg=`🔔 NgFX Day Trade\n${sig.direction==="BUY"?"🟢 BUY":"🔴 SELL"} ${sig.pair}\nEntry: ${sig.entry} | SL: ${sig.sl}\nTP1: ${sig.calc?.tp1} | TP2: ${sig.calc?.tp2} | TP3: ${sig.calc?.tp3}\nProbability: ${sig.prob}%\nMax hold: ${DT.maxHoldMins/60}h\n${sig.reasons[0]}\n— NgFX by Nguruh`;await fetch(tgUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:msg})});}catch(e){}
  },[tgUrl]);

  const runScan=useCallback(async()=>{
    if(ns.blocked||limitReached()||isPastClose())return;
    const pairs=getActivePairs();
    setScanCount(n=>n+1);
    for(let idx=0;idx<pairs.length;idx++){
      const pair=pairs[idx];
      await new Promise(r=>setTimeout(r,idx*500));
      const data=await getPairData(pair);
      setChartData(cd=>({...cd,[pair]:data}));
      const{signals:found,partialScore:ps,ck:fCk,bias}=runStrategy(pair,data);
      const now=new Date().toLocaleTimeString("en-GB",{hour:"2-digit",minute:"2-digit"});
      setFormation(f=>({...f,[pair]:{partialScore:ps,ck:fCk,rsi:calcRSI(data.m15.map(c=>c.close)),bias}}));
      const qualified=found.filter(s=>s.score>=minScore);
      if(qualified.length>0){
        const stamped=qualified.map(s=>attachCalc({...s,id:`${Date.now()}-${Math.random()}`,time:now,createdAt:Date.now(),result:null,tp1Hit:false,tp2Hit:false,tp3Hit:false,slHit:false}));
        setSignals(prev=>[...stamped,...prev]);
        setHistory(prev=>[...stamped,...prev].slice(0,500));
        stamped.forEach(s=>{pushSignalNotif(s);if(soundOn)playSound(s.direction);sendTg(s);});
      }
    }
  },[ns,limitReached,minScore,attachCalc,soundOn,sendTg]);

  // TP/SL price monitor — runs every 30s, checks live price vs signal levels
  const monitorTPSL=useCallback(async()=>{
    setSignals(prev=>{
      const active=prev.filter(s=>!s.result&&!s.slHit);
      if(!active.length)return prev;
      let changed=false;
      const updated=prev.map(sig=>{
        if(sig.result||sig.slHit)return sig;
        const cd=chartData[sig.pair];
        const currentPrice=cd?.price;
        if(!currentPrice)return sig;
        const hit=checkTPSL(sig,currentPrice);
        if(!hit)return sig;
        changed=true;
        pushTPSLNotif(sig,hit);
        if(hit.type==="profit"){playTPSound();}else{playSLSound();}
        return{
          ...sig,
          tp1Hit: hit.level==="TP1"?true:sig.tp1Hit,
          tp2Hit: hit.level==="TP2"?true:sig.tp2Hit,
          tp3Hit: hit.level==="TP3"?true:sig.tp3Hit,
          slHit:  hit.level==="SL" ?true:sig.slHit,
          result: hit.level==="SL"?"loss":hit.level==="TP3"?"win":sig.result,
        };
      });
      return changed?updated:prev;
    });
  },[chartData]);

  // Auto-expire signals after maxHoldMins
  useEffect(()=>{const i=setInterval(()=>{const cut=Date.now()-DT.maxHoldMins*60*1000;setSignals(prev=>prev.filter(s=>s.createdAt>cut||s.result));}  ,60000);return()=>clearInterval(i);},[]);

  const startCD=useCallback((ms)=>{clearInterval(cntRef.current);secsRef.current=Math.floor(ms/1000);setSecsLeft(secsRef.current);cntRef.current=setInterval(()=>{secsRef.current-=1;setSecsLeft(secsRef.current);if(secsRef.current<=0)clearInterval(cntRef.current);},1000);},[]);

  // AUTO-START — runs immediately on mount, no button needed
  useEffect(()=>{
    const go=async()=>{
      await runScan();
      const ms=getScanMs();setIMs(ms);startCD(ms);
      intRef.current=setInterval(async()=>{const nms=getScanMs();setIMs(nms);startCD(nms);await runScan();},ms);
      // TP/SL monitor every 30s
      const tpMon=setInterval(monitorTPSL,30000);
      return()=>clearInterval(tpMon);
    };
    go();
    return()=>{clearInterval(intRef.current);clearInterval(cntRef.current);};
  },[]);// eslint-disable-line

  const doNotif=async()=>{const ok=await askNotif();setNotifPerm(ok?"granted":"denied");};
  const dismiss=id=>setSignals(prev=>prev.filter(s=>s.id!==id));
  const markResult=(id,result)=>{
    const s=signals.find(x=>x.id===id);
    if(s){const d=result==="win"?parseFloat(s.calc?.potProfit2||0):-parseFloat(s.calc?.riskAmount||0);setDailyPnl(p=>+(p+d).toFixed(2));}
    const upd=s=>s.id===id?{...s,result}:s;
    setSignals(prev=>prev.map(upd));setHistory(prev=>prev.map(upd));
  };

  const lim=limitReached(),noTrade=isPastClose();
  const TABS=[{k:"charts",l:"Charts"},{k:"live",l:`Signals${signals.length>0?` (${signals.length})`:""}`},{k:"analytics",l:"Analytics"},{k:"guide",l:"Guide"}];
  const sessLabel=SESS[getSess()].label;

  return(
    <div style={{minHeight:"100vh",background:C.bg,color:C.text,fontFamily:FD,maxWidth:480,margin:"0 auto",position:"relative"}}>
      <div style={{position:"fixed",inset:0,overflow:"hidden",pointerEvents:"none",zIndex:0}}>
        <div style={{position:"absolute",width:500,height:500,borderRadius:"50%",background:"radial-gradient(circle,rgba(240,180,41,0.05) 0%,transparent 70%)",top:-150,left:-150,animation:"orbF1 14s ease-in-out infinite"}}/>
        <div style={{position:"absolute",width:350,height:350,borderRadius:"50%",background:"radial-gradient(circle,rgba(96,165,250,0.04) 0%,transparent 70%)",bottom:50,right:-100,animation:"orbF2 18s ease-in-out infinite"}}/>
      </div>

      <div style={{position:"relative",zIndex:1}}>
        {/* HEADER */}
        <div style={{padding:"0.9rem 1rem 0.7rem",borderBottom:`1px solid ${C.border}`,position:"sticky",top:0,zIndex:10,background:"rgba(4,6,14,0.92)",backdropFilter:"blur(24px)"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <svg width="38" height="38" viewBox="0 0 44 44" fill="none"><rect width="44" height="44" rx="12" fill="url(#lgBg3)" opacity="0.95"/><rect width="44" height="44" rx="12" fill="none" stroke="rgba(240,180,41,0.45)" strokeWidth="1"/><rect x="8" y="16" width="5" height="15" rx="1.5" fill={C.green}/><line x1="10.5" y1="11" x2="10.5" y2="16" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/><line x1="10.5" y1="31" x2="10.5" y2="35" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/><rect x="17" y="20" width="5" height="11" rx="1.5" fill={C.red}/><line x1="19.5" y1="14" x2="19.5" y2="20" stroke={C.red} strokeWidth="1.5" strokeLinecap="round"/><line x1="19.5" y1="31" x2="19.5" y2="35" stroke={C.red} strokeWidth="1.5" strokeLinecap="round"/><rect x="26" y="12" width="5" height="19" rx="1.5" fill={C.green}/><line x1="28.5" y1="8" x2="28.5" y2="12" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/><line x1="28.5" y1="31" x2="28.5" y2="36" stroke={C.green} strokeWidth="1.5" strokeLinecap="round"/><path d="M7 36 Q15 28 22 30 Q29 32 37 20" stroke={C.gold} strokeWidth="1.8" fill="none" strokeLinecap="round"/><circle cx="37" cy="20" r="2.5" fill={C.gold}/><defs><linearGradient id="lgBg3" x1="0" y1="0" x2="44" y2="44"><stop offset="0%" stopColor="rgba(240,180,41,0.18)"/><stop offset="100%" stopColor="rgba(8,12,24,0.95)"/></linearGradient></defs></svg>
              <div>
                <div style={{display:"flex",alignItems:"baseline",gap:1}}>
                  <span style={{fontSize:20,fontWeight:900,color:C.goldLight,letterSpacing:"-0.04em",lineHeight:1,textShadow:`0 0 24px ${C.goldGlow}`}}>Ng</span>
                  <span style={{fontSize:20,fontWeight:900,color:C.text,letterSpacing:"-0.04em",lineHeight:1}}>FX</span>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:6,marginTop:1}}>
                  <span style={{fontSize:8,color:C.textMuted,letterSpacing:"0.14em",textTransform:"uppercase",fontFamily:FM}}>Day Trader</span>
                  <span style={{fontSize:8,padding:"1px 6px",borderRadius:99,background:USE_LIVE_DATA?"rgba(52,211,153,0.1)":"rgba(251,191,36,0.1)",color:USE_LIVE_DATA?C.green:C.amber,fontFamily:FM}}>● {USE_LIVE_DATA?"LIVE":"DEMO"}</span>
                  <span style={{fontSize:8,padding:"1px 6px",borderRadius:99,background:"rgba(96,165,250,0.08)",color:C.blue,fontFamily:FM}}>{license.daysLeft}d left</span>
                </div>
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5}}>
              <div style={{textAlign:"right"}}>
                {(()=>{const[t,setT]=useState(new Date());useEffect(()=>{const i=setInterval(()=>setT(new Date()),1000);return()=>clearInterval(i);},[]);return(<><div style={{fontSize:13,fontWeight:700,fontFamily:FM,color:C.text}}>{t.toUTCString().slice(17,22)}<span style={{color:C.textMuted,fontSize:10}}> UTC</span></div><div style={{fontSize:9,color:isHighProb()?C.green:C.textMuted}}>{SESS[getSess()].emoji} {sessLabel}</div></>);})()}
              </div>
              <button onClick={()=>setShowCap(v=>!v)} style={{padding:"5px 10px",background:showCap?C.goldDim:"rgba(255,255,255,0.04)",color:C.gold,border:`1px solid ${C.gold}44`,borderRadius:8,cursor:"pointer",fontSize:10,fontWeight:700,fontFamily:FM}}>⚙ ${capital.toLocaleString()}</button>
            </div>
          </div>

          {/* Settings panel */}
          {showCap&&(
            <div style={{background:"rgba(6,10,20,0.98)",border:`1px solid ${C.gold}33`,borderRadius:18,padding:"1.2rem",marginBottom:12,backdropFilter:"blur(24px)",boxShadow:`0 0 40px ${C.goldGlow}`}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
                <div style={{fontSize:15,fontWeight:800,color:C.text,fontFamily:FD}}>Settings</div>
                <button onClick={()=>setShowCap(false)} style={{width:28,height:28,borderRadius:"50%",background:"rgba(255,255,255,0.06)",border:"none",color:C.textSub,cursor:"pointer",fontSize:13,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
              </div>
              {[
                {label:"Account balance (USD)",type:"number",val:capital,set:setCapital,prefix:"$",min:100,step:100},
              ].map(({label,type,val,set,prefix,min,step})=>(
                <div key={label} style={{marginBottom:12}}>
                  <label style={{fontSize:10,color:C.textMuted,display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:"0.06em",fontFamily:FM}}>{label}</label>
                  <div style={{position:"relative"}}>{prefix&&<span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",fontSize:15,color:C.gold,fontWeight:800,fontFamily:FM}}>{prefix}</span>}<input type={type} value={val} min={min} step={step} onChange={e=>set(+e.target.value)} style={{width:"100%",padding:`11px 12px 11px ${prefix?"30px":"12px"}`,background:"rgba(255,255,255,0.04)",border:`1px solid ${C.glassBorder}`,borderRadius:10,color:C.text,fontSize:16,fontFamily:FM,fontWeight:700,outline:"none",boxSizing:"border-box"}}/></div>
                </div>
              ))}
              {[[riskPct,setRiskPct,"Risk per trade",0.5,5,0.5,riskPct<=1?C.green:riskPct<=2?C.amber:C.red,`${riskPct}%·$${((capital*riskPct)/100).toFixed(0)}`],[dailyLimit,setDailyLimit,"Daily loss limit",0,10,0.5,C.red,dailyLimit===0?"Off":`${dailyLimit}%`],[minScore,setMinScore,"Min signal score",55,100,5,C.amber,`${minScore}+`]].map(([val,set,label,min,max,step,col,display])=>(
                <div key={label} style={{marginBottom:12}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><label style={{fontSize:10,color:C.textMuted,textTransform:"uppercase",letterSpacing:"0.06em",fontFamily:FM}}>{label}</label><span style={{fontSize:12,fontWeight:800,color:col,fontFamily:FM}}>{display}</span></div>
                  <input type="range" min={min} max={max} step={step} value={val} onChange={e=>set(+e.target.value)} style={{width:"100%",accentColor:col}}/>
                </div>
              ))}
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12,background:"rgba(255,255,255,0.03)",borderRadius:10,padding:"9px 12px",border:`1px solid ${C.border}`}}>
                <div><div style={{fontSize:12,color:C.text,fontFamily:FD}}>Sound alerts</div></div>
                <div onClick={()=>setSoundOn(v=>!v)} style={{width:40,height:22,borderRadius:11,background:soundOn?C.green:"rgba(255,255,255,0.08)",cursor:"pointer",position:"relative",transition:"background 0.2s",border:`1px solid ${soundOn?C.green:C.border}`}}><div style={{position:"absolute",top:3,left:soundOn?20:3,width:14,height:14,borderRadius:"50%",background:"#fff",transition:"left 0.2s"}}/></div>
              </div>
              <div style={{marginBottom:14}}>
                <label style={{fontSize:10,color:C.textMuted,display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:"0.06em",fontFamily:FM}}>Telegram webhook</label>
                <input type="text" value={tgUrl} onChange={e=>setTgUrl(e.target.value)} placeholder="https://api.telegram.org/bot..." style={{width:"100%",padding:"9px 11px",background:"rgba(255,255,255,0.03)",border:`1px solid ${C.border}`,borderRadius:9,color:C.text,fontSize:11,fontFamily:FM,outline:"none",boxSizing:"border-box"}}/>
              </div>
            </div>
          )}

          {notifPerm!=="granted"&&<div style={{background:"rgba(240,180,41,0.06)",border:`1px solid ${C.gold}28`,borderRadius:10,padding:"7px 12px",display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}><span style={{fontSize:11,color:C.gold}}>🔔 Enable alerts — get TP/SL notifications</span><button onClick={doNotif} style={{background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,color:"#1a1000",border:"none",borderRadius:7,padding:"4px 12px",fontSize:10,fontWeight:800,cursor:"pointer",fontFamily:FM,flexShrink:0,marginLeft:10}}>ALLOW</button></div>}

          {ns.blocked&&<div style={{background:"rgba(251,191,36,0.07)",border:`1px solid ${C.amber}40`,borderRadius:10,padding:"7px 12px",marginBottom:8,display:"flex",gap:8,alignItems:"center"}}><span style={{fontSize:12}}>⚠️</span><div><div style={{fontSize:11,fontWeight:700,color:C.amber,fontFamily:FM}}>News filter — {ns.label}</div><div style={{fontSize:9,color:C.textMuted,fontFamily:FM}}>Scanning paused ±30min</div></div></div>}

          {dailyLimit>0&&<div style={{marginBottom:8}}>
            {(()=>{const lAmt=(capital*dailyLimit)/100,loss=Math.abs(Math.min(dailyPnl,0)),pct=Math.min(loss/lAmt,1),col=pct>=1?C.red:pct>=0.7?C.amber:C.green;return(<><div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:C.textMuted,marginBottom:3,fontFamily:FM}}><span>Daily loss limit</span><span style={{color:col}}>${loss.toFixed(0)} / ${lAmt.toFixed(0)}</span></div><div style={{height:3,background:"rgba(255,255,255,0.04)",borderRadius:99,overflow:"hidden"}}><div style={{height:"100%",width:`${pct*100}%`,background:col,borderRadius:99}}/></div></>);})()}
          </div>}

          {/* Next scan bar */}
          <div style={{marginBottom:6}}>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:C.textMuted,marginBottom:3,textTransform:"uppercase",letterSpacing:"0.07em",fontFamily:FM}}>
              <span style={{color:noTrade?C.amber:lim?C.red:C.green}}>● {noTrade?"Trading closed 7pm UTC":lim?"Daily limit reached":"Auto-scanning · "+scanCount+" runs"}</span>
              <span style={{fontFamily:FM,color:C.textSub}}>{Math.floor(secsLeft/60)>0?`${Math.floor(secsLeft/60)}m `:""}{secsLeft%60}s · P&L: <span style={{color:dailyPnl>=0?C.green:C.red}}>{dailyPnl>=0?"+":""}{dailyPnl.toFixed(2)}</span></span>
            </div>
            <div style={{height:2,background:"rgba(255,255,255,0.04)",borderRadius:99,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${iMs>0?Math.max(0,1-secsLeft/(iMs/1000))*100:0}%`,background:isHighProb()?`linear-gradient(90deg,${C.green},${C.gold})`:`linear-gradient(90deg,${C.blue},${C.purple})`,borderRadius:99,transition:"width 1s linear"}}/>
            </div>
          </div>
        </div>

        {/* TABS */}
        <div style={{display:"flex",borderBottom:`1px solid ${C.border}`,background:"rgba(4,6,14,0.82)",backdropFilter:"blur(20px)",position:"sticky",top:0,zIndex:9}}>
          {TABS.map(t=><button key={t.k} onClick={()=>setTab(t.k)} style={{flex:1,padding:"12px 4px",background:"none",border:"none",cursor:"pointer",fontSize:10,fontWeight:700,letterSpacing:"0.06em",textTransform:"uppercase",color:tab===t.k?C.text:C.textMuted,borderBottom:`2px solid ${tab===t.k?C.gold:"transparent"}`,fontFamily:FM,transition:"color 0.2s",whiteSpace:"nowrap"}}>{t.l}</button>)}
        </div>

        {/* CONTENT */}
        <div style={{padding:"1rem 1rem 3rem"}}>

          {tab==="charts"&&(
            <div>
              <div style={{fontSize:11,color:C.textMuted,fontFamily:FM,marginBottom:12,lineHeight:1.6,background:"rgba(255,255,255,0.02)",borderRadius:10,padding:"8px 12px",border:`1px solid ${C.border}`}}>
                {USE_LIVE_DATA?<span>Connected to <span style={{color:C.green}}>Twelve Data live feed</span> · Charts refresh every scan</span>:<span style={{color:C.amber}}>Demo mode — <span style={{color:C.gold}}>add your Twelve Data API key</span> to go live</span>}
              </div>
              {PAIRS.map(pair=>{
                const cd=chartData[pair],fm=formation[pair],latestSig=signals.find(s=>s.pair===pair&&!s.result);
                return(<div key={pair} style={{marginBottom:14}}><MiniChart pair={pair} candles={cd?.m15} price={cd?.price} partialScore={fm?.partialScore||0} minScore={minScore} ck={fm?.ck||[]} rsiVal={fm?.rsi} bias={fm?.bias} latestSignal={latestSig}/></div>);
              })}
            </div>
          )}

          {tab==="live"&&(
            <>
              {signals.length===0&&(
                <div style={{textAlign:"center",padding:"3rem 1rem"}}>
                  <div style={{opacity:0.18,marginBottom:18,display:"inline-block",animation:"shimmer 3s ease-in-out infinite"}}>
                    <svg width="64" height="64" viewBox="0 0 44 44" fill="none"><rect width="44" height="44" rx="12" fill="rgba(240,180,41,0.1)"/><rect width="44" height="44" rx="12" fill="none" stroke="rgba(240,180,41,0.3)" strokeWidth="1.5"/><rect x="8" y="16" width="5" height="15" rx="1.5" fill={C.green}/><rect x="17" y="20" width="5" height="11" rx="1.5" fill={C.red}/><rect x="26" y="12" width="5" height="19" rx="1.5" fill={C.green}/><path d="M7 36 Q15 28 22 30 Q29 32 37 20" stroke={C.gold} strokeWidth="1.8" fill="none" strokeLinecap="round"/><circle cx="37" cy="20" r="2.5" fill={C.gold}/></svg>
                  </div>
                  <div style={{fontSize:14,fontWeight:700,color:C.textSub,marginBottom:8,fontFamily:FD}}>{noTrade?"🌙 Trading closed — resumes 7am UTC":lim?"⛔ Daily limit reached — scanner paused":ns.blocked?`⚠️ News paused — ${ns.label}`:"Scanning markets — signals appear here"}</div>
                  <div style={{fontSize:11,color:C.textMuted,fontFamily:FM,lineHeight:1.8}}>Auto-scanning · Unlimited signals<br/>TP & SL notifications · Max {DT.maxHoldMins/60}h hold</div>
                </div>
              )}
              {signals.map(s=><SignalCard key={s.id} sig={s} onDismiss={()=>dismiss(s.id)} onMark={markResult}/>)}
            </>
          )}

          {tab==="analytics"&&<Analytics history={history}/>}

          {tab==="guide"&&(
            <div style={{fontSize:12,lineHeight:1.85,color:C.textSub}}>
              {[
                {t:"Connecting live market data",b:`NgFX uses Twelve Data for live forex and gold prices.\n\n1. Go to twelvedata.com and create a free account\n2. Copy your API key from the dashboard\n3. Open the NgFX source file (NgFX.jsx)\n4. Find the line: const TWELVE_DATA_KEY = "YOUR_API_KEY"\n5. Replace YOUR_API_KEY with your actual key\n6. Save and redeploy — the LIVE badge appears in the header\n\nFree tier gives 800 requests/day and 8/minute — enough for all 3 pairs scanning every 2 minutes.`},
                {t:"Installing on Android",b:`1. Open Chrome on your Android phone\n2. Go to your NgFX URL (your hosting link)\n3. Tap the three-dot menu (⋮) in the top right\n4. Tap "Add to Home Screen"\n5. Name it "NgFX" and tap Add\n6. It installs as a full-screen app — no browser bar\n7. Tap ALLOW for notifications so you get TP/SL alerts\n\nNgFX works on any Android phone with Chrome. It also works on iPhone (Safari → Share → Add to Home Screen) and as a desktop web app.`},
                {t:"Installing on iPhone",b:`1. Open Safari (must be Safari, not Chrome)\n2. Go to your NgFX URL\n3. Tap the Share button (box with arrow pointing up)\n4. Scroll down and tap "Add to Home Screen"\n5. Tap Add in the top right\n6. Opens as a full-screen app\n\nNote: iPhone PWA notifications have limited support. For full push notifications, use Android Chrome.`},
                {t:"Generating and selling license keys",b:`Keys are in the format: NGFX-YYYYMMDD-XXXXXXXX\n\nTo generate a key for a buyer:\n1. Take today's date + 30 days: e.g. 20261225\n2. Generate 8 random hex characters: open browser console, type: Math.random().toString(16).slice(2,10).toUpperCase()\n3. Combine: NGFX-20261225-A3F8B201\n4. Send this key to your buyer\n5. Key automatically expires on 25 Dec 2026\n\nTo sell renewals: generate a new key with an updated expiry date. Keys are cheap to create — just date + random hex. No server needed for validation.\n\nRecommended pricing: $20–$30 per 30-day key. You keep 100% — no platform fees.`},
                {t:"TP and SL notifications",b:"NgFX monitors every active signal's price levels automatically. When the live price hits TP1, TP2, TP3, or SL, you instantly get:\n• A push notification to your phone\n• A distinct sound (rising tones for TP, falling tones for SL)\n• The signal card updates with a hit badge\n\nFor TP3 hits, the trade auto-marks as Win. For SL hits, it marks as Loss and updates your daily P&L."},
                {t:"Day trader rules",b:`Every signal in NgFX is intraday only:\n• M5 and M15 entry timeframes only\n• Maximum 4-hour hold time per trade\n• Scanner stops at 7pm UTC to prevent overnight exposure\n• Each signal card shows a close-by time in UTC\n• Signals auto-expire after 4 hours\n• No signals during news windows (±30 min around high-impact events)`},
                {t:"Telegram signal channel",b:"To broadcast signals to paying subscribers:\n1. Create a Telegram bot via @BotFather\n2. Get your bot token and your channel chat ID\n3. Build the webhook URL: https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={CHAT_ID}\n4. Paste this URL in NgFX Settings → Telegram webhook\n5. Every signal automatically posts to your channel\n\nSubscribers join your Telegram channel — you don't need to give them the app. Charge separately for Telegram access vs app access."},
              ].map(({t,b})=>(
                <div key={t} style={{marginBottom:22,paddingBottom:22,borderBottom:`1px solid ${C.border}`}}>
                  <div style={{fontSize:10,color:C.gold,fontWeight:800,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.1em",fontFamily:FM}}>{t}</div>
                  <div style={{fontFamily:FD,whiteSpace:"pre-line"}}>{b}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  ROOT — License gate wraps the main app
// ══════════════════════════════════════════════════════════════════════════════
export default function App(){
  const[license,setLicense]=useState(null);
  const[checking,setChecking]=useState(true);

  useEffect(()=>{
    // Check for saved license on load
    const saved=getLicenseFromStorage();
    if(saved){
      const v=validateLicense(saved);
      if(v.valid){setLicense(v);}
    }
    setChecking(false);
  },[]);

  if(checking) return(
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{fontSize:12,color:C.textMuted,fontFamily:FM}}>Loading NgFX…</div>
    </div>
  );

  if(!license) return <LicenseScreen onUnlock={setLicense}/>;
  return <MainApp license={license}/>;
}
